package com.ust.task.spring_security.controler;

//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.authentication.AuthenticationManager;
//import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
//import org.springframework.security.core.Authentication;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.ust.task.spring_security.entity.MyUser;
//import com.ust.task.spring_security.service.MyUserDetailsService;
//
//@RestController
//@RequestMapping("/api")
//public class DemoControler {
//	
//	@Autowired
//	private AuthenticationManager am;
//
//	@Autowired
//	private MyUserDetailsService muds;
//	@GetMapping
////	@PreAuthorize("hasAuthority('user')")
//	public String home() {
//		return "you are Home";
//	}
//	
//	@GetMapping("/contact")
//	public String contact() {
//		return "you can contact me";
//	}
//	
//	@PostMapping("/add")
//	public String contact(@RequestBody MyUser user) {
//		System.out.println("Userrr is = "+user);
//		muds.signup(user);
//		return "Signed Up";
//	
//	}
////	@GetMapping("/login/{username}/{password}")
////	public String contact(@PathVariable String username, @PathVariable String password) {
////		Authentication	auth = am.authenticate(new UsernamePasswordAuthenticationToken(username, password));
////		if(auth.isAuthenticated()) {
////			return "Login Success";
////		}else {
////			return "Login failed";
////		}
////	}
//}


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ust.task.spring_security.entity.MyUser;
import com.ust.task.spring_security.service.MyUserDetailsService;
 
@RestController
@RequestMapping("/api/v1")
public class DemoControler {
	@Autowired
	private MyUserDetailsService muds;
	@Autowired
	private AuthenticationManager am;
 
	@GetMapping
	public String home() {
		return "Welcome to home";
	}
	@GetMapping("/contact")
	public String contact() {
		return "Contact us";
	}
	@PostMapping("/login")
	public String login(@RequestBody MyUser user) {
		//authenticate here....
		Authentication auth = am.authenticate(new UsernamePasswordAuthenticationToken(user.getUsername(), user.getPassword()));
		if(auth.isAuthenticated()) {
			return "Login is successful";
		}else
		{
			return "Failed";
		}
	}
	@PostMapping("/signup")
	public String signup(@RequestBody MyUser user) {
		System.out.println(user);
		muds.signup(user);
		return "Signup is successful";
	}

	@GetMapping("/users")
	public List<MyUser> getAllUsers() {
		return muds.read();
	}
}