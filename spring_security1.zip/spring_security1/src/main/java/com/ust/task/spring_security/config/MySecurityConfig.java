package com.ust.task.spring_security.config;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.authentication.AuthenticationManager;
//import org.springframework.security.authentication.AuthenticationProvider;
//import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
//import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
//import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.security.web.SecurityFilterChain;
//
//import com.ust.task.spring_security.service.MyUserDetailsService;
//
//@Configuration
//@EnableMethodSecurity
//public class MySecurityConfig {
//
//	@Autowired
//	private MyUserDetailsService muds;
//
//	@Bean
//	public PasswordEncoder passwordencorder() {
//		return new BCryptPasswordEncoder();
//	}
//	
//	@Bean
//	public AuthenticationProvider authenticationProvider() {
//		DaoAuthenticationProvider auth = new DaoAuthenticationProvider();
//		auth.setPasswordEncoder(passwordencorder());
//		auth.setUserDetailsService(muds);
//		return auth;
//	}
//	
//	@Bean
//	public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception{
//		return config.getAuthenticationManager();
//	}
//	
//	
//	
//	
//	
//	
//	
//	@Bean
//	public SecurityFilterChain securityFilterchain(HttpSecurity http) throws Exception{
//		return http.csrf(csrf->csrf.disable())
//				.authorizeHttpRequests(auth->auth.requestMatchers("/api/***").permitAll())
//				.authorizeHttpRequests(auth->auth.requestMatchers("/h2-console/").permitAll())
//				.build();
//	}
//
//	
//}

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer.FrameOptionsConfig;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.RequestMatcher;

@Configuration
@EnableMethodSecurity
public class MySecurityConfig {
	@Autowired
	private UserDetailsService muds;

	@Bean
	public PasswordEncoder passwordEncoder() {
//		return NoOpPasswordEncoder.getInstance();
		return new BCryptPasswordEncoder();
	}
	
	@Bean
	public AuthenticationProvider authProvider() {
		DaoAuthenticationProvider auth = new DaoAuthenticationProvider();
		auth.setPasswordEncoder(passwordEncoder());
		auth.setUserDetailsService(muds);
		return auth;
	}
	
	
	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        return http.csrf(csrf -> csrf.disable())       		
        		
                .authorizeHttpRequests(auth -> auth.requestMatchers("/api/v1/**").permitAll())
                .authorizeHttpRequests(auth -> auth.requestMatchers("/api/v2/**").authenticated())
                
                .build();
    }
	 
	 @Bean
	 public AuthenticationManager authenticateManager(AuthenticationConfiguration config) throws Exception {
		 return config.getAuthenticationManager();
	 }
}