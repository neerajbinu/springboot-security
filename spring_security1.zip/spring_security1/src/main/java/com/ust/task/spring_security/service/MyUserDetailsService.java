package com.ust.task.spring_security.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.ust.task.spring_security.entity.MyUser;
import com.ust.task.spring_security.repository.UserRepo;
 
@Service
public class MyUserDetailsService implements UserDetailsService {
	@Autowired
	private PasswordEncoder passwordEncoder;
	@Autowired
	private UserRepo mur;
 
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
//		List<GrantedAuthority> roles=new ArrayList<>();
//		roles.add(new SimpleGrantedAuthority("admin"));
//		roles.add(new SimpleGrantedAuthority("user"));
//		return new User("sharon", "abcd", roles);
		Optional<MyUser> temp = mur.findById(username);
		MyUser mu=null;
		if(temp.isPresent()) {
			mu=temp.get();
		}else {
			throw new UsernameNotFoundException("Login failed");
		}
		String[] arr = mu.getRoles().split(",");
		List<GrantedAuthority> roles=new ArrayList<>();
		for(String role:arr) {
			roles.add(new SimpleGrantedAuthority(role));
		}
		return new User(mu.getUsername(), mu.getPassword(), roles);
	}
 
	
	public void signup(MyUser mu) {
		mu.setPassword(passwordEncoder.encode(mu.getPassword()));
		mur.save(mu);
	}
	public List<MyUser> read() {
		return mur.findAll();
	}

}